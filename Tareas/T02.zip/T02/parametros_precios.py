# Precio de los recursos
PRECIO_ALACACHOFAS = 10
PRECIO_CHOCLOS = 10
PRECIO_LEÑA = 20
PRECIO_ORO = 40

# Precio de las semillas
PRECIO_SEMILLA_ALCACHOFAS = 1
PRECIO_SEMILLA_CHOCLOS = 5

# Precio de las herramientas
PRECIO_HACHA = 50
PRECIO_AZADA = 30

# Otros
PRECIO_TICKET = 1500
