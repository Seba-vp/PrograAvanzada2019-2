import os

# Información de los choclos
TIEMPO_CHOCLOS = 180
FASES_CHOCLOS = 7
COSECHA_CHOCLOS = 3
PATH_SPRITES_CHOCLOS = os.path.join("sprites", "cultivos", "choclo")

# Información de las alcachofas
TIEMPO_ALCACHOFAS = 60
FASES_ALCACHOFAS = 6
COSECHA_ALCACHOFAS = 1
PATH_SPRITES_ALCACHOFAS = os.path.join("sprites", "cultivos", "alcachofa")
